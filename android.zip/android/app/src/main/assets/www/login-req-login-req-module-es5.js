function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-req-login-req-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/login-req/login-req.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login-req/login-req.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppLoginReqLoginReqPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>loginReq</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-button expand=\"block\" fill=\"outline\" color=\"primary\" (click)=\"redirectToPage('sign-in')\">Sign in</ion-button>\n  <ion-button expand=\"block\" fill=\"outline\" color=\"primary\" (click)=\"redirectToPage('sign-up')\">Sign up</ion-button>\n  <ion-button size=\"large\" fill=\"outline\" color=\"primary\" (click)=\"exitApp()\">Close</ion-button>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/login-req/login-req-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/login-req/login-req-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: LoginReqPageRoutingModule */

  /***/
  function srcAppLoginReqLoginReqRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginReqPageRoutingModule", function () {
      return LoginReqPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _login_req_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./login-req.page */
    "./src/app/login-req/login-req.page.ts");

    var routes = [{
      path: '',
      component: _login_req_page__WEBPACK_IMPORTED_MODULE_3__["LoginReqPage"]
    }];

    var LoginReqPageRoutingModule = function LoginReqPageRoutingModule() {
      _classCallCheck(this, LoginReqPageRoutingModule);
    };

    LoginReqPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], LoginReqPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/login-req/login-req.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/login-req/login-req.module.ts ***!
    \***********************************************/

  /*! exports provided: LoginReqPageModule */

  /***/
  function srcAppLoginReqLoginReqModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginReqPageModule", function () {
      return LoginReqPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _login_req_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./login-req-routing.module */
    "./src/app/login-req/login-req-routing.module.ts");
    /* harmony import */


    var _login_req_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./login-req.page */
    "./src/app/login-req/login-req.page.ts");

    var LoginReqPageModule = function LoginReqPageModule() {
      _classCallCheck(this, LoginReqPageModule);
    };

    LoginReqPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _login_req_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginReqPageRoutingModule"]],
      declarations: [_login_req_page__WEBPACK_IMPORTED_MODULE_6__["LoginReqPage"]]
    })], LoginReqPageModule);
    /***/
  },

  /***/
  "./src/app/login-req/login-req.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/login-req/login-req.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppLoginReqLoginReqPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xvZ2luLXJlcS9sb2dpbi1yZXEucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/login-req/login-req.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/login-req/login-req.page.ts ***!
    \*********************************************/

  /*! exports provided: LoginReqPage */

  /***/
  function srcAppLoginReqLoginReqPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginReqPage", function () {
      return LoginReqPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var LoginReqPage = /*#__PURE__*/function () {
      function LoginReqPage(alertController, router, ngZone, platform) {
        _classCallCheck(this, LoginReqPage);

        this.alertController = alertController;
        this.router = router;
        this.ngZone = ngZone;
        this.platform = platform;
        this.platform = platform;
      }

      _createClass(LoginReqPage, [{
        key: "presentAlert",
        value: function presentAlert() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.alertController.create({
                      header: '',
                      subHeader: 'Securite notification',
                      message: 'Acces not authorised',
                      buttons: [{
                        text: 'sign-in',
                        cssClass: 'secondary',
                        handler: function handler(blah) {
                          _this.redirectToPage('sign-in');
                        }
                      }, {
                        text: 'sign-up',
                        handler: function handler() {
                          _this.redirectToPage('sign-up');
                        }
                      }]
                    });

                  case 2:
                    alert = _context.sent;
                    _context.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.presentAlert();
        }
      }, {
        key: "redirectToPage",
        value: function redirectToPage(page) {
          var _this2 = this;

          // As we are calling the Angular router navigation inside a subscribe method, the navigation will be triggered outside Angular zone.
          // That's why we need to wrap the router navigation call inside an ngZone wrapper
          this.ngZone.run(function () {
            _this2.router.navigate([page]);
          });
        }
      }, {
        key: "exitApp",
        value: function exitApp() {
          navigator['app'].exitApp();
        }
      }]);

      return LoginReqPage;
    }();

    LoginReqPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }];
    };

    LoginReqPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-login-req',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./login-req.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/login-req/login-req.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./login-req.page.scss */
      "./src/app/login-req/login-req.page.scss"))["default"]]
    }), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]])], LoginReqPage);
    /***/
  }
}]);
//# sourceMappingURL=login-req-login-req-module-es5.js.map