(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pocket-pocket-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pocket/pocket.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pocket/pocket.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>  \n  <ion-toolbar><ion-back-button text=\"home\" defaultHref=\"home\"></ion-back-button>\n    <ion-title>pocket</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"error-container\">\n    <div class=\"error-message\">\n      <ion-icon name=\"information-circle-outline\"></ion-icon>\n    \n    </div>\n  </div>\n  <div>\n    <iframe width=\"940px\" height= \"980px\" src=\"https://script.google.com/macros/s/AKfycbwqH7acNmRVdNV2P5TyO0Wm18erjqeerE4vkNdYzwvwI6bNBjkqcOkw3B8NnH-giEJyUg/exec?index=2\" frameborder= \"0\" marginwidth= \"0\" marginheight= \"0\" style= \"border: none; max-width:100%; max-height:100vh\" allowfullscreen webkitallowfullscreen mozallowfullscreen msallowfullscreen></iframe>\n   \n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pocket/pocket-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pocket/pocket-routing.module.ts ***!
  \*************************************************/
/*! exports provided: PocketPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PocketPageRoutingModule", function() { return PocketPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _profile_profile_resolver__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! .././profile/profile.resolver */ "./src/app/profile/profile.resolver.ts");
/* harmony import */ var _profile_profile_can_activate_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! .././profile/profile-can-activate.guard */ "./src/app/profile/profile-can-activate.guard.ts");
/* harmony import */ var _pocket_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pocket.page */ "./src/app/pocket/pocket.page.ts");






const routes = [
    {
        path: '',
        component: _pocket_page__WEBPACK_IMPORTED_MODULE_5__["PocketPage"], resolve: {
            data: _profile_profile_resolver__WEBPACK_IMPORTED_MODULE_3__["ProfilePageResolver"]
        },
        canActivate: [_profile_profile_can_activate_guard__WEBPACK_IMPORTED_MODULE_4__["ProfilePageGuard"]],
    }
];
let PocketPageRoutingModule = class PocketPageRoutingModule {
};
PocketPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]], providers: [_profile_profile_resolver__WEBPACK_IMPORTED_MODULE_3__["ProfilePageResolver"], _profile_profile_can_activate_guard__WEBPACK_IMPORTED_MODULE_4__["ProfilePageGuard"]]
    })
], PocketPageRoutingModule);



/***/ }),

/***/ "./src/app/pocket/pocket.module.ts":
/*!*****************************************!*\
  !*** ./src/app/pocket/pocket.module.ts ***!
  \*****************************************/
/*! exports provided: PocketPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PocketPageModule", function() { return PocketPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _pocket_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pocket-routing.module */ "./src/app/pocket/pocket-routing.module.ts");
/* harmony import */ var _pocket_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pocket.page */ "./src/app/pocket/pocket.page.ts");







let PocketPageModule = class PocketPageModule {
};
PocketPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _pocket_routing_module__WEBPACK_IMPORTED_MODULE_5__["PocketPageRoutingModule"]
        ],
        declarations: [_pocket_page__WEBPACK_IMPORTED_MODULE_6__["PocketPage"]]
    })
], PocketPageModule);



/***/ }),

/***/ "./src/app/pocket/pocket.page.scss":
/*!*****************************************!*\
  !*** ./src/app/pocket/pocket.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BvY2tldC9wb2NrZXQucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/pocket/pocket.page.ts":
/*!***************************************!*\
  !*** ./src/app/pocket/pocket.page.ts ***!
  \***************************************/
/*! exports provided: PocketPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PocketPage", function() { return PocketPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let PocketPage = class PocketPage {
    constructor() { }
    ngOnInit() {
    }
};
PocketPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pocket',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./pocket.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pocket/pocket.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./pocket.page.scss */ "./src/app/pocket/pocket.page.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
], PocketPage);



/***/ })

}]);
//# sourceMappingURL=pocket-pocket-module-es2015.js.map