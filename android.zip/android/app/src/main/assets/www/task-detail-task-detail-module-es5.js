function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["task-detail-task-detail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/task-detail/task-detail.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/task-detail/task-detail.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTaskDetailTaskDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/tasks\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Details</ion-title>\n  </ion-toolbar>\n</ion-header>\n \n<ion-content >\n\n  <ion-list  >\n  \n    <ion-item> <label for=\"\">id :</label>\n      <ion-input required type=\"text\" placeholder=\"Task\" [(ngModel)]=\"taskId\"></ion-input>\n    </ion-item>\n    <ion-item> <label for=\"\">Name :</label>\n      <ion-input required type=\"text\" placeholder=\"Task\" [(ngModel)]=\"task.task \"></ion-input>\n    </ion-item>\n    <ion-item> \n      <label  color=\"danger\" for=\"\"> Priorite :</label>\n  \n      <ion-input required type=\"number\" placeholder=\"Priority\" [(ngModel)]=\"task.priority\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-icon  name=\"alarm-outline\"></ion-icon> <label for=\"\"> Creat AT:</label> \n      <ion-input type=\"date\" value =\"number\" placeholder=\"created at\" [(ngModel)]=\"task.createdAt  \"></ion-input>\n    </ion-item>\n    <ion-item>\n      <label color=\"primary\" for=\"\">Closed AT:</label>\n      <ion-input type=\"date\"  value=\"number \" placeholder=\"Priority\" [(ngModel)]=\"task.closedAt\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <label for=\"\"></label><span>Closed :</span>\n    \n      <ion-checkbox id=\"checkbox\" [(ngModel)]=\"task.closed\"></ion-checkbox>\n    </ion-item>\n   \n  </ion-list>\n  <ion-button expand=\"full\" (click)=\"saveTodo(task)\">Save</ion-button>\n  <ion-button expand=\"full\" (click)=\"removeTask(taskId)\" color=\"danger\"  >Delete</ion-button>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/task-detail/task-detail-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/task-detail/task-detail-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: TaskDetailPageRoutingModule */

  /***/
  function srcAppTaskDetailTaskDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TaskDetailPageRoutingModule", function () {
      return TaskDetailPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _profile_profile_resolver__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! .././profile/profile.resolver */
    "./src/app/profile/profile.resolver.ts");
    /* harmony import */


    var _profile_profile_can_activate_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! .././profile/profile-can-activate.guard */
    "./src/app/profile/profile-can-activate.guard.ts");
    /* harmony import */


    var _task_detail_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./task-detail.page */
    "./src/app/task-detail/task-detail.page.ts");

    var routes = [{
      path: '',
      component: _task_detail_page__WEBPACK_IMPORTED_MODULE_5__["TaskDetailPage"]
    }];

    var TaskDetailPageRoutingModule = function TaskDetailPageRoutingModule() {
      _classCallCheck(this, TaskDetailPageRoutingModule);
    };

    TaskDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
      providers: [_profile_profile_resolver__WEBPACK_IMPORTED_MODULE_3__["ProfilePageResolver"], _profile_profile_can_activate_guard__WEBPACK_IMPORTED_MODULE_4__["ProfilePageGuard"]]
    })], TaskDetailPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/task-detail/task-detail.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/task-detail/task-detail.module.ts ***!
    \***************************************************/

  /*! exports provided: TaskDetailPageModule */

  /***/
  function srcAppTaskDetailTaskDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TaskDetailPageModule", function () {
      return TaskDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _task_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./task-detail-routing.module */
    "./src/app/task-detail/task-detail-routing.module.ts");
    /* harmony import */


    var _task_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./task-detail.page */
    "./src/app/task-detail/task-detail.page.ts");

    var TaskDetailPageModule = function TaskDetailPageModule() {
      _classCallCheck(this, TaskDetailPageModule);
    };

    TaskDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _task_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["TaskDetailPageRoutingModule"]],
      declarations: [_task_detail_page__WEBPACK_IMPORTED_MODULE_6__["TaskDetailPage"]]
    })], TaskDetailPageModule);
    /***/
  },

  /***/
  "./src/app/task-detail/task-detail.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/task-detail/task-detail.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTaskDetailTaskDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".checkbox {\n  --checkmark-width:\"60px\";\n  --color: rgb(201, 119, 12);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFzay1kZXRhaWwvQzpcXFVzZXJzXFxhY2hpZ1xcaW9uaWNfcHJqXFxpb25pYzUtZmlyZWJhc2Uvc3JjXFxhcHBcXHRhc2stZGV0YWlsXFx0YXNrLWRldGFpbC5wYWdlLnNjc3MiLCJzcmMvYXBwL3Rhc2stZGV0YWlsL3Rhc2stZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUFVLHdCQUFBO0VBQ04sMEJBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL3Rhc2stZGV0YWlsL3Rhc2stZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jaGVja2JveHstLWNoZWNrbWFyay13aWR0aCA6XCI2MHB4XCI7XHJcbiAgICAtLWNvbG9yOiByZ2IoMjAxLCAxMTksIDEyKTt9XHJcbiIsIi5jaGVja2JveCB7XG4gIC0tY2hlY2ttYXJrLXdpZHRoOlwiNjBweFwiO1xuICAtLWNvbG9yOiByZ2IoMjAxLCAxMTksIDEyKTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/task-detail/task-detail.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/task-detail/task-detail.page.ts ***!
    \*************************************************/

  /*! exports provided: TaskDetailPage */

  /***/
  function srcAppTaskDetailTaskDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TaskDetailPage", function () {
      return TaskDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/fire/firestore */
    "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-firestore.js");

    var TaskDetailPage = /*#__PURE__*/function () {
      function TaskDetailPage(router, route, nav, fireStore, loadingController) {
        _classCallCheck(this, TaskDetailPage);

        this.router = router;
        this.route = route;
        this.nav = nav;
        this.fireStore = fireStore;
        this.loadingController = loadingController;
        this.task = {
          task: 'test',
          createdAt: new Date().getTime(),
          priority: 2,
          closedAt: '',
          closed: false
        };
        this.taskId = null;
        this.todosCollection = this.fireStore.collection('tasks');
      }

      _createClass(TaskDetailPage, [{
        key: "updateTask",
        value: function updateTask(todo, id) {
          return this.todosCollection.doc(id).update(todo);
        }
      }, {
        key: "addTask",
        value: function addTask(todo) {
          var _this = this;

          return this.todosCollection.add(todo).then(function () {
            _this.router.navigateByUrl('/tasks');
          })["catch"](function (err) {
            console.error(err);
          });
        }
      }, {
        key: "removeTask",
        value: function removeTask(id) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this2 = this;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    return _context.abrupt("return", this.todosCollection.doc(id)["delete"]().then(function () {
                      _this2.router.navigateByUrl('/tasks');
                    })["catch"](function (err) {
                      console.error(err);
                    }));

                  case 1:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "getTodo",
        value: function getTodo(id) {
          return this.todosCollection.doc(id).valueChanges();
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.taskId = this.route.snapshot.params.id;

          if (this.taskId) {
            this.loadTodo();
          }
        }
      }, {
        key: "loadTodo",
        value: function loadTodo() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this3 = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.loadingController.create({
                      message: 'Loading Todo..'
                    });

                  case 2:
                    loading = _context2.sent;
                    _context2.next = 5;
                    return loading.present();

                  case 5:
                    this.getTodo(this.taskId).subscribe(function (res) {
                      _this3.todos = res;
                      loading.dismiss();
                      _this3.task = _this3.todos;
                    });

                  case 6:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "lireTodo",
        value: function lireTodo() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    this.loadTodo;
                    this.task = this.todos;

                  case 2:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "gotaskpage",
        value: function gotaskpage() {
          this.router.navigateByUrl('/tasks');
        }
      }, {
        key: "saveTodo",
        value: function saveTodo() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var loading;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.loadingController.create({
                      message: 'Saving Todo..'
                    });

                  case 2:
                    loading = _context4.sent;
                    _context4.next = 5;
                    return loading.present();

                  case 5:
                    if (this.taskId) {
                      this.updateTask(this.task, this.taskId).then(function () {
                        loading.dismiss();
                      });
                    } else {
                      this.addTask(this.task).then(function () {
                        loading.dismiss();
                      });
                    }

                  case 6:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }]);

      return TaskDetailPage;
    }();

    TaskDetailPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__["AngularFirestore"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }];
    };

    TaskDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-task-detail',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./task-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/task-detail/task-detail.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./task-detail.page.scss */
      "./src/app/task-detail/task-detail.page.scss"))["default"]]
    }), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__["AngularFirestore"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]])], TaskDetailPage);
    /***/
  }
}]);
//# sourceMappingURL=task-detail-task-detail-module-es5.js.map