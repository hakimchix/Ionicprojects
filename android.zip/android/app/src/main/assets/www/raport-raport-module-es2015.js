(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["raport-raport-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/raport/raport.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/raport/raport.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n\n  <ion-toolbar> \n    <ion-buttons slot=\"end\">\n      <ion-back-button text=\"Home\" defaultHref=\"home\"></ion-back-button>\n    </ion-buttons>\n   \n    <ion-title>raport</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content >\n  <h1></h1>\n  <ion-buttons slot=\"end\">\n    <ion-back-button text=\"back\" icon=\"add\" ></ion-back-button>\n  </ion-buttons>\n  <div>\n \n    <ion-button size=\"small\" color=\"{{show1 ? 'medium' : 'secondary'}}\" (click)=\"show1 = !show1\">{{show1 ? 'hide rapport 1' : 'show rapport 1 '}}</ion-button>\n  <ion-button size=\"small\"  color=\"{{show2 ? 'medium' : 'secondary'}}\" (click)=\"show2 = !show2\">{{show2 ? 'hide rapport 2' : 'show rapport 2'}}</ion-button>\n  <ion-button  size=\"small\" color=\"{{show3 ? 'medium' : 'secondary'}}\" (click)=\"show3 = !show3\">{{show3 ? 'hide rapport 3' : 'show rapport 3'}}</ion-button>\n</div>\n <br> <div *ngIf=\"(show1 && show2 )||(show3 && show2 )||(show3 && show1 )\" >\n <ion-label  color='primary' > slide  rapports</ion-label>\n</div>\n <br>\n <ion-item>\n <ion-slides pager=\"true\" >\n  <ion-slide>\n \n    <div  *ngIf=\"show1\" >\n      <iframe width=\"940px\" height= \"980px\" src= \"https://script.google.com/macros/s/AKfycbwqH7acNmRVdNV2P5TyO0Wm18erjqeerE4vkNdYzwvwI6bNBjkqcOkw3B8NnH-giEJyUg/exec?index=1\" frameborder= \"0\" marginwidth= \"0\" marginheight= \"0\" style= \"border: none; max-width:100%; max-height:100vh\" allowfullscreen webkitallowfullscreen mozallowfullscreen msallowfullscreen> </iframe>\n    </div>\n  </ion-slide>\n  <ion-slide>\n  \n    <div  *ngIf=\"show2\">\n      <iframe width=\"640px\" height= \"680px\" src= \"https://docs.google.com/spreadsheets/d/e/2PACX-1vSByr-49t_4DLfRely4kHi2WXySwF-y9r36i75-aLb47njZ4rrGjbHPnajWWtzTiyyvMk6RhXQo3W5a/pubhtml?gid=1026767447&single=true\" frameborder= \"0\" marginwidth= \"0\" marginheight= \"0\" style= \"border: none; max-width:100%; max-height:100vh\" allowfullscreen webkitallowfullscreen mozallowfullscreen msallowfullscreen> </iframe>\n     \n    </div>\n  </ion-slide>\n  <ion-slide>\n   \n    <div *ngIf=\"show3\">\n      <iframe width=\"640px\" height= \"680px\" src= \"https://docs.google.com/spreadsheets/d/1WfwIP18HsubgpYn7V9waBDiFHKsMaLUf4mR2-ckKuAo/edit?usp=sharing\" frameborder= \"0\" marginwidth= \"0\" marginheight= \"0\" style= \"border: none; max-width:100%; max-height:100vh\" allowfullscreen webkitallowfullscreen mozallowfullscreen msallowfullscreen> </iframe>\n    </div>\n  </ion-slide>\n</ion-slides>\n  \n</ion-item>\n  \n\n  \n</ion-content>\n");

/***/ }),

/***/ "./src/app/raport/raport-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/raport/raport-routing.module.ts ***!
  \*************************************************/
/*! exports provided: RaportPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RaportPageRoutingModule", function() { return RaportPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _profile_profile_resolver__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! .././profile/profile.resolver */ "./src/app/profile/profile.resolver.ts");
/* harmony import */ var _profile_profile_can_activate_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! .././profile/profile-can-activate.guard */ "./src/app/profile/profile-can-activate.guard.ts");
/* harmony import */ var _raport_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./raport.page */ "./src/app/raport/raport.page.ts");






const routes = [
    {
        path: '',
        component: _raport_page__WEBPACK_IMPORTED_MODULE_5__["RaportPage"]
    }
];
let RaportPageRoutingModule = class RaportPageRoutingModule {
};
RaportPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]], providers: [_profile_profile_resolver__WEBPACK_IMPORTED_MODULE_3__["ProfilePageResolver"], _profile_profile_can_activate_guard__WEBPACK_IMPORTED_MODULE_4__["ProfilePageGuard"]]
    })
], RaportPageRoutingModule);



/***/ }),

/***/ "./src/app/raport/raport.module.ts":
/*!*****************************************!*\
  !*** ./src/app/raport/raport.module.ts ***!
  \*****************************************/
/*! exports provided: RaportPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RaportPageModule", function() { return RaportPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _raport_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./raport-routing.module */ "./src/app/raport/raport-routing.module.ts");
/* harmony import */ var _raport_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./raport.page */ "./src/app/raport/raport.page.ts");







let RaportPageModule = class RaportPageModule {
};
RaportPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _raport_routing_module__WEBPACK_IMPORTED_MODULE_5__["RaportPageRoutingModule"]
        ],
        declarations: [_raport_page__WEBPACK_IMPORTED_MODULE_6__["RaportPage"]]
    })
], RaportPageModule);



/***/ }),

/***/ "./src/app/raport/raport.page.scss":
/*!*****************************************!*\
  !*** ./src/app/raport/raport.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JhcG9ydC9yYXBvcnQucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/raport/raport.page.ts":
/*!***************************************!*\
  !*** ./src/app/raport/raport.page.ts ***!
  \***************************************/
/*! exports provided: RaportPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RaportPage", function() { return RaportPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let RaportPage = class RaportPage {
    constructor() { }
    ngOnInit() {
    }
};
RaportPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-raport',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./raport.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/raport/raport.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./raport.page.scss */ "./src/app/raport/raport.page.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
], RaportPage);



/***/ })

}]);
//# sourceMappingURL=raport-raport-module-es2015.js.map