function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tasks-tasks-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tasks/tasks.page.html":
  /*!*****************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tasks/tasks.page.html ***!
    \*****************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTasksTasksPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar> <ion-back-button text=\"Home\" defaultHref=\"home\"></ion-back-button>\n    <ion-title>tasks</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-button color=\"success\"  (click)=\"gettasks()\">get  all tasks</ion-button>\n  <ion-button color=\"primary\" (click)=\"getopentask(false)\">get opened tasks</ion-button>\n  <ion-button color=\"primary\" (click)=\"getopentask(true)\">get close tasks</ion-button>\n  \n  <ion-list>\n\n    <ng-container *ngIf=\"!tasks || tasks.length == 0\">\n      <div *ngFor=\"let n of [0,1,2]\" padding>\n        <ion-skeleton-text>{{n}}</ion-skeleton-text>\n        <p>\n          <ion-skeleton-text class=\"fake-skeleton\"></ion-skeleton-text>\n        </p>\n      </div>\n    </ng-container>\n \n    <ion-item-sliding *ngFor=\"let item of tasks\">\n      <ion-item [color]=\" priority_color(item.priority)\" lines=\"inset\" button [href]=\"['task-detail/' + item.id]\">\n      <ion-note>Task Name</ion-note>  <ion-label>\n          {{ item.task}}    </ion-label> <ion-label>\n            <ion-note color=\"dark\">Date of Creation :</ion-note>\n\n          <p>{{ item.createdAt | date:'short' }}</p>\n        </ion-label>\n        <ion-note color=\"dark\">priority:</ion-note>\n        {{ item.priority }}\n        <ion-item  [color]=\" priority_color(item.priority)\" slot=\"start\">\n        \n       <ion-item  [color]=\" priority_color(item.priority)\">  <ion-note color=\"dark\">Colsed:</ion-note>\n        <ion-checkbox id=\"checkbox\" [(ngModel)]=\"item.closed\" disabled=true> </ion-checkbox>\n      </ion-item>\n      </ion-item>\n      </ion-item>\n    <ion-item>\n      <ion-item>\n      \n      </ion-item>\n        \n        </ion-item>\n       \n      <ion-item-options >\n         \n        <ion-item-option  (click)=\"remove(item.id)\" color=\"danger\" expandable=true>\n          <ion-icon slot=\"icon-only\" name=\"trash\"></ion-icon>\n          \n        </ion-item-option>\n        \n      </ion-item-options>\n      <ion-item-options side=\"start\">\n        <ion-item-option (click)=\"close(item)\"  color=\"success\" expandable=true type=\"button\">\n        Close\n        </ion-item-option>\n          <ion-item-option (click)=\"open(item)\"  color=\"danger\"  expandable=true type=\"button\">\n           Open\n        </ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n \n  </ion-list>\n \n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button routerLink=\"/task-detail\" routerDirection=\"forward\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n \n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/tasks/tasks-routing.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/tasks/tasks-routing.module.ts ***!
    \***********************************************/

  /*! exports provided: TasksPageRoutingModule */

  /***/
  function srcAppTasksTasksRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TasksPageRoutingModule", function () {
      return TasksPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _profile_profile_resolver__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! .././profile/profile.resolver */
    "./src/app/profile/profile.resolver.ts");
    /* harmony import */


    var _profile_profile_can_activate_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! .././profile/profile-can-activate.guard */
    "./src/app/profile/profile-can-activate.guard.ts");
    /* harmony import */


    var _tasks_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./tasks.page */
    "./src/app/tasks/tasks.page.ts");

    var routes = [{
      path: '',
      component: _tasks_page__WEBPACK_IMPORTED_MODULE_5__["TasksPage"],
      resolve: {
        data: _profile_profile_resolver__WEBPACK_IMPORTED_MODULE_3__["ProfilePageResolver"]
      },
      canActivate: [_profile_profile_can_activate_guard__WEBPACK_IMPORTED_MODULE_4__["ProfilePageGuard"]]
    }];

    var TasksPageRoutingModule = function TasksPageRoutingModule() {
      _classCallCheck(this, TasksPageRoutingModule);
    };

    TasksPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
      providers: [_profile_profile_resolver__WEBPACK_IMPORTED_MODULE_3__["ProfilePageResolver"], _profile_profile_can_activate_guard__WEBPACK_IMPORTED_MODULE_4__["ProfilePageGuard"]]
    })], TasksPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/tasks/tasks.module.ts":
  /*!***************************************!*\
    !*** ./src/app/tasks/tasks.module.ts ***!
    \***************************************/

  /*! exports provided: TasksPageModule */

  /***/
  function srcAppTasksTasksModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TasksPageModule", function () {
      return TasksPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _tasks_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./tasks-routing.module */
    "./src/app/tasks/tasks-routing.module.ts");
    /* harmony import */


    var _tasks_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./tasks.page */
    "./src/app/tasks/tasks.page.ts");

    var TasksPageModule = function TasksPageModule() {
      _classCallCheck(this, TasksPageModule);
    };

    TasksPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _tasks_routing_module__WEBPACK_IMPORTED_MODULE_5__["TasksPageRoutingModule"]],
      declarations: [_tasks_page__WEBPACK_IMPORTED_MODULE_6__["TasksPage"]]
    })], TasksPageModule);
    /***/
  },

  /***/
  "./src/app/tasks/tasks.page.scss":
  /*!***************************************!*\
    !*** ./src/app/tasks/tasks.page.scss ***!
    \***************************************/

  /*! exports provided: default */

  /***/
  function srcAppTasksTasksPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "#checkbox {\n  background-color: transparent;\n  border-bottom: #75be63 solid 4px;\n  font-family: \"Ionicons\";\n  display: inline-block;\n  --checkmark-width:10px;\n  --size:25px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFza3MvQzpcXFVzZXJzXFxhY2hpZ1xcaW9uaWNfcHJqXFxpb25pYzUtZmlyZWJhc2Uvc3JjXFxhcHBcXHRhc2tzXFx0YXNrcy5wYWdlLnNjc3MiLCJzcmMvYXBwL3Rhc2tzL3Rhc2tzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDZCQUFBO0VBQ0osZ0NBQUE7RUFDQSx1QkFBQTtFQUNBLHFCQUFBO0VBQ0Esc0JBQUE7RUFDQSxXQUFBO0FDQ0EiLCJmaWxlIjoic3JjL2FwcC90YXNrcy90YXNrcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY2hlY2tib3h7IFxyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbmJvcmRlci1ib3R0b206IHJnYigxMTcsIDE5MCwgOTkpIHNvbGlkIDRweDtcclxuZm9udC1mYW1pbHk6IFwiSW9uaWNvbnNcIjtcclxuZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4tLWNoZWNrbWFyay13aWR0aDoxMHB4O1xyXG4tLXNpemU6MjVweDtcclxuICAgIH1cclxuIiwiI2NoZWNrYm94IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1ib3R0b206ICM3NWJlNjMgc29saWQgNHB4O1xuICBmb250LWZhbWlseTogXCJJb25pY29uc1wiO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIC0tY2hlY2ttYXJrLXdpZHRoOjEwcHg7XG4gIC0tc2l6ZToyNXB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/tasks/tasks.page.ts":
  /*!*************************************!*\
    !*** ./src/app/tasks/tasks.page.ts ***!
    \*************************************/

  /*! exports provided: TasksPage */

  /***/
  function srcAppTasksTasksPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TasksPage", function () {
      return TasksPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/fire/firestore */
    "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-firestore.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var TasksPage = /*#__PURE__*/function () {
      function TasksPage(fireStore) {
        _classCallCheck(this, TasksPage);

        this.fireStore = fireStore;
        this.todosCollection = fireStore.collection('tasks');
        this.taskObsrv = this.todosCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (actions) {
          return actions.map(function (a) {
            var data = a.payload.doc.data();
            var id = a.payload.doc.id;
            return Object.assign({
              id: id
            }, data);
          });
        }));
      }

      _createClass(TasksPage, [{
        key: "getopenTasks",
        value: function getopenTasks(d) {
          return this.todosCollection.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (actions) {
            return actions.map(function (a) {
              var data = a.payload.doc.data();
              var id = a.payload.doc.id;
              return Object.assign({
                id: id
              }, data);
            }).filter(function (a) {
              return a.closed === d;
            });
          }));
        }
      }, {
        key: "getopentask",
        value: function getopentask(d) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    this.getopenTasks(d).subscribe(function (res) {
                      _this.tasks = res;
                    });

                  case 1:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "gettasks",
        value: function gettasks() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this2 = this;

            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    this.taskObsrv.subscribe(function (a) {
                      _this2.tasks = a;
                    });

                  case 1:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.gettasks();
        }
      }, {
        key: "priority_color",
        value: function priority_color(i) {
          switch (i) {
            case 1:
              {
                return "danger";
                break;
              }

            case 2:
              {
                //statements; 
                return "primary";
                break;
              }

            case 3:
              {
                //statements; 
                return "light";
                break;
              }

            default:
              {
                //statements; 
                return "dark";
                break;
              }
          }
        }
      }, {
        key: "close",
        value: function close(item) {}
      }, {
        key: "open",
        value: function open(item) {}
      }, {
        key: "remove",
        value: function remove(item) {}
      }]);

      return TasksPage;
    }();

    TasksPage.ctorParameters = function () {
      return [{
        type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"]
      }];
    };

    TasksPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-tasks',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./tasks.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tasks/tasks.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./tasks.page.scss */
      "./src/app/tasks/tasks.page.scss"))["default"]]
    }), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"]])], TasksPage);
    /***/
  }
}]);
//# sourceMappingURL=tasks-tasks-module-es5.js.map